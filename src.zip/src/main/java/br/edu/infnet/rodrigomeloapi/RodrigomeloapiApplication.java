package br.edu.infnet.rodrigomeloapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RodrigomeloapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RodrigomeloapiApplication.class, args);
	}

}
